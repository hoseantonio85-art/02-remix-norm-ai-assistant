export interface QueueProgressProps {
  elements?: string[];
  progress?: number;
  className?: string;
}
