import { useId, KeyboardEvent } from 'react';
import { useTranslation } from 'react-i18next';
import cn from 'classnames';

import {
  Row,
  Text,
  Icon,
  Popover,
  ScrollBar,
  useComponentVisible,
} from '@sber-orm/ui-kit';

import { QueueProgressProps } from './types';
import classes from './styles.module.scss';

const RADIUS = 15;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

const TRACK_GRADIENT = [
  { offset: '0%', color: 'rgb(233, 237, 248)' },
  { offset: '100%', color: 'rgb(240, 234, 247)' },
];
const FILL_GRADIENT = [
  { offset: '0%', color: 'rgb(83, 255, 244)' },
  { offset: '50%', color: 'rgb(93, 90, 249)' },
  { offset: '100%', color: 'rgb(175, 23, 250)' },
];

export const QueueProgress = ({
  elements,
  progress = 0,
  className,
}: QueueProgressProps) => {
  const { t } = useTranslation();
  const gradientId = useId();

  const { isComponentVisible, setIsComponentVisible, visibleRef } =
    useComponentVisible<HTMLDivElement>(false, undefined);

  const length = elements?.length ?? 0;
  const hasElements = length > 0;

  const normalizedProgress = Math.min(100, Math.max(0, progress * 100));
  const offset = CIRCUMFERENCE * (1 - normalizedProgress / 100);

  const togglePopover = () => {
    if (!hasElements) return;
    setIsComponentVisible((prev) => !prev);
  };

  const closePopover = () => {
    if (isComponentVisible) setIsComponentVisible(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    switch (e.key) {
      case 'Enter':
      case ' ':
        e.preventDefault();
        togglePopover();
        break;

      case 'Escape':
        e.preventDefault();
        closePopover();
        break;
    }
  };

  return (
    <>
      <div
        data-testid='queue-progress-trigger'
        className={cn(
          classes.processingInfo,
          { [classes.processingInfoActive]: hasElements },
          className,
        )}
        ref={visibleRef}
        onClick={togglePopover}
        onKeyDown={handleKeyDown}
        role='button'
        tabIndex={hasElements ? 0 : -1}
        aria-expanded={isComponentVisible}
        aria-haspopup='dialog'
        aria-disabled={!hasElements}
      >
        <Row align='middle'>
          <Row gutter={8}>
            <div
              className={cn(classes.processingInfoIconWrapper, {
                [classes.processingInfoIconWrapperActive]: hasElements,
              })}
            >
              {hasElements && (
                <svg
                  data-testid='queue-progress-ring'
                  className={classes.progressRing}
                  viewBox='0 0 32 32'
                  aria-hidden
                >
                  <defs>
                    <linearGradient
                      id={`track-${gradientId}`}
                      x1='0'
                      y1='0'
                      x2='1'
                      y2='1'
                    >
                      {TRACK_GRADIENT.map((stop) => (
                        <stop
                          key={stop.offset}
                          offset={stop.offset}
                          stopColor={stop.color}
                        />
                      ))}
                    </linearGradient>
                    <linearGradient
                      id={`fill-${gradientId}`}
                      x1='0'
                      y1='0'
                      x2='1'
                      y2='1'
                    >
                      {FILL_GRADIENT.map((stop) => (
                        <stop
                          key={stop.offset}
                          offset={stop.offset}
                          stopColor={stop.color}
                        />
                      ))}
                    </linearGradient>
                  </defs>

                  <circle cx='16' cy='16' r='14' fill='#fff' />

                  <circle
                    cx='16'
                    cy='16'
                    r={RADIUS}
                    stroke={`url(#track-${gradientId})`}
                    strokeWidth='2'
                    fill='none'
                  />

                  <circle
                    className={classes.progressRingFill}
                    cx='16'
                    cy='16'
                    r={RADIUS}
                    stroke={`url(#fill-${gradientId})`}
                    strokeWidth='2'
                    fill='none'
                    strokeLinecap='round'
                    strokeDasharray={CIRCUMFERENCE}
                    strokeDashoffset={offset}
                    transform='rotate(-90 16 16)'
                  />
                </svg>
              )}

              <Icon name='generateGradient' width={20} height={20} />
            </div>
            <Row direction='column' align='stretch'>
              <Text bold>{t('inProcessing')}</Text>
              <Text
                size='sm'
                className={cn(classes.processingInfoText, {
                  [classes.processingInfoTextActive]: hasElements,
                })}
              >
                {hasElements
                  ? t('agents', { count: length })
                  : t('thereIsNothing')}
              </Text>
            </Row>
          </Row>
        </Row>
      </div>

      {hasElements && isComponentVisible && (
        <Popover
          anchor={visibleRef.current}
          open
          data-testid='queue-progress-popover'
        >
          <ScrollBar className={classes.scrollbar}>
            {elements?.map((el, index) => {
              const isFirst = index === 0;
              return (
                <Row
                  key={`${el}-${index}`}
                  data-testid={`queue-progress-item-${index}`}
                  direction='column'
                  align='stretch'
                  className={classes.queueItem}
                >
                  <Text bold>{el}</Text>
                  <Text
                    size='sm'
                    className={
                      isFirst
                        ? classes.queueItemTextActive
                        : classes.queueItemText
                    }
                  >
                    {isFirst ? t('inProcessing') : t('queue')}
                  </Text>
                </Row>
              );
            })}
          </ScrollBar>
        </Popover>
      )}
    </>
  );
};
