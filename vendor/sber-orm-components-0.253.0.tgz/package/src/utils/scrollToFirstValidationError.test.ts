import { describe, it, expect, vi, beforeEach } from 'vitest';

import {
  scrollToFirstValidationError,
  findScrollParent,
} from './scrollToFirstValidationError';

/**
 * Мокает getComputedStyle так, чтобы указанные элементы имели нужные overflow-свойства.
 * Остальные элементы получают 'visible' по умолчанию.
 */
function mockGetComputedStyle(
  rules: Record<string, { overflowY: string; overflowX: string }>,
) {
  const originalGetComputedStyle = window.getComputedStyle;
  vi.spyOn(window, 'getComputedStyle').mockImplementation(
    (node: Element) => {
      const key =
        node.getAttribute('data-testid') ?? node.tagName ?? 'default';
      const rule = rules[key];

      if (rule) {
        return {
          ...originalGetComputedStyle(node),
          overflowY: rule.overflowY,
          overflowX: rule.overflowX,
        } as CSSStyleDeclaration;
      }

      // Если для элемента нет правила — не scrollable (visible)
      return {
        ...originalGetComputedStyle(node),
        overflowY: 'visible' as const,
        overflowX: 'visible' as const,
      } as CSSStyleDeclaration;
    },
  );
}

describe('findScrollParent', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
    vi.restoreAllMocks();
  });

  it('возвращает null, если нет scrollable-родителя', () => {
    const child = document.createElement('div');
    document.body.appendChild(child);
    child.setAttribute('data-testid', 'child');

    mockGetComputedStyle({
      child: { overflowY: 'visible', overflowX: 'visible' },
      BODY: { overflowY: 'visible', overflowX: 'visible' },
    });

    expect(findScrollParent(child)).toBeNull();
  });

  it('находит ближайший scrollable-родитель', () => {
    const container = document.createElement('div');
    container.setAttribute('data-testid', 'container');
    container.style.overflow = 'auto';

    const child = document.createElement('div');
    child.setAttribute('data-testid', 'child');
    container.appendChild(child);
    document.body.appendChild(container);

    mockGetComputedStyle({
      container: { overflowY: 'auto', overflowX: 'visible' },
      child: { overflowY: 'visible', overflowX: 'visible' },
    });

    expect(findScrollParent(child)).toBe(container);
  });

  it('игнорирует не-scrollable промежуточные элементы', () => {
    const scrollable = document.createElement('div');
    scrollable.setAttribute('data-testid', 'scrollable');
    scrollable.style.overflowY = 'scroll';

    const wrapper = document.createElement('div');
    wrapper.setAttribute('data-testid', 'wrapper');

    const child = document.createElement('div');
    child.setAttribute('data-testid', 'child');

    scrollable.appendChild(wrapper);
    wrapper.appendChild(child);
    document.body.appendChild(scrollable);

    mockGetComputedStyle({
      scrollable: { overflowY: 'scroll', overflowX: 'visible' },
      wrapper: { overflowY: 'visible', overflowX: 'visible' },
      child: { overflowY: 'visible', overflowX: 'visible' },
    });

    expect(findScrollParent(child)).toBe(scrollable);
  });
});

describe('scrollToFirstValidationError', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
    vi.restoreAllMocks();
  });

  it('возвращает false, если нет элементов с aria-invalid="true"', () => {
    document.body.innerHTML = '<div><input /></div>';

    expect(scrollToFirstValidationError()).toBe(false);
  });

  it('скроллит к первому элементу с aria-invalid="true" через scrollIntoView', () => {
    document.body.innerHTML = `
      <div>
        <div aria-invalid="true" style="height: 100px;">
          <input />
        </div>
        <div aria-invalid="true" style="height: 100px;">
          <input />
        </div>
      </div>
    `;

    const scrollIntoViewMock = vi.fn();
    const firstField = document.querySelector(
      '[aria-invalid="true"]',
    ) as HTMLElement;
    firstField.scrollIntoView = scrollIntoViewMock;

    const result = scrollToFirstValidationError();

    expect(scrollIntoViewMock).toHaveBeenCalledWith({
      block: 'center',
      behavior: 'smooth',
    });
    expect(result).toBe(true);
  });

  it('использует переданный root-контейнер для поиска', () => {
    const container = document.createElement('div');
    container.innerHTML = '<div aria-invalid="true"><input /></div>';
    document.body.appendChild(container);

    const scrollIntoViewMock = vi.fn();
    const errorField = container.querySelector(
      '[aria-invalid="true"]',
    ) as HTMLElement;
    errorField.scrollIntoView = scrollIntoViewMock;

    scrollToFirstValidationError(container);

    expect(scrollIntoViewMock).toHaveBeenCalled();
  });

  it('не находит ошибки, если root передан, но aria-invalid вне него', () => {
    const container = document.createElement('div');
    container.innerHTML = '<div><input /></div>';
    document.body.innerHTML = '<div aria-invalid="true"><input /></div>';
    document.body.appendChild(container);

    expect(scrollToFirstValidationError(container)).toBe(false);
  });

  it('фокусирует первый фокусируемый элемент внутри поля с ошибкой', () => {
    document.body.innerHTML = `
      <div>
        <div aria-invalid="true">
          <input type="text" />
        </div>
      </div>
    `;

    const input = document.querySelector('input') as HTMLInputElement;
    const focusMock = vi.fn();
    input.focus = focusMock;

    const firstField = document.querySelector(
      '[aria-invalid="true"]',
    ) as HTMLElement;
    firstField.scrollIntoView = vi.fn();

    scrollToFirstValidationError();

    expect(focusMock).toHaveBeenCalledWith({ preventScroll: true });
  });

  it('не падает, если внутри поля нет фокусируемого элемента', () => {
    document.body.innerHTML = `
      <div>
        <div aria-invalid="true">просто текст</div>
      </div>
    `;

    const firstField = document.querySelector(
      '[aria-invalid="true"]',
    ) as HTMLElement;
    firstField.scrollIntoView = vi.fn();

    const result = scrollToFirstValidationError();

    expect(result).toBe(true);
  });

  it('скроллит scrollable-контейнер, а не сам элемент (если есть scrollParent)', () => {
    const container = document.createElement('div');
    container.setAttribute('data-testid', 'container');
    container.style.overflow = 'auto';
    container.style.height = '200px';

    const inner = document.createElement('div');
    inner.setAttribute('data-testid', 'inner');
    inner.style.height = '1000px';
    container.appendChild(inner);
    document.body.appendChild(container);

    const errorField = document.createElement('div');
    errorField.setAttribute('aria-invalid', 'true');
    errorField.setAttribute('data-testid', 'error');
    errorField.style.marginTop = '300px';
    errorField.innerHTML = '<input />';
    inner.appendChild(errorField);

    mockGetComputedStyle({
      container: { overflowY: 'auto', overflowX: 'visible' },
      inner: { overflowY: 'visible', overflowX: 'visible' },
      error: { overflowY: 'visible', overflowX: 'visible' },
    });

    const scrollToMock = vi.fn();
    container.scrollTo = scrollToMock;

    scrollToFirstValidationError();

    expect(scrollToMock).toHaveBeenCalled();
    const args = scrollToMock.mock.calls[0][0];
    expect(args).toHaveProperty('behavior', 'smooth');
    expect(typeof args.top).toBe('number');
    expect(args.top).toBeGreaterThanOrEqual(0);
  });
});