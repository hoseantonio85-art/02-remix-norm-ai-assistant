/** CSS-селектор для поиска первого поля с ошибкой валидации. */
export const ERROR_SELECTOR = '[aria-invalid="true"]';

/** CSS-селектор для поиска фокусируемого элемента внутри поля. */
const FOCUSABLE_SELECTOR = [
  'input',
  'textarea',
  'select',
  'button',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

/**
 * Определяет, является ли элемент scrollable-контейнером
 * (имеет overflow: auto | scroll).
 */
function isScrollableNode(node: HTMLElement): boolean {
  const { overflowY, overflowX } = getComputedStyle(node);

  return (
    overflowY === 'auto' ||
    overflowY === 'scroll' ||
    overflowX === 'auto' ||
    overflowX === 'scroll'
  );
}

/**
 * Поднимается по DOM-дереву в поисках ближайшего scrollable-родителя.
 *
 * @param element - элемент, от которого начинается поиск
 * @returns ближайший scrollable-родитель или null, если таковой не найден
 */
export function findScrollParent(element: HTMLElement): HTMLElement | null {
  let current = element.parentElement;

  while (current) {
    if (isScrollableNode(current)) {
      return current;
    }
    current = current.parentElement;
  }

  return null;
}

/**
 * Пытается сфокусировать первый фокусируемый элемент внутри контейнера.
 *
 * @param container - контейнер, внутри которого ищется фокусируемый элемент
 */
function focusFirstFocusable(container: HTMLElement): void {
  const focusable = container.querySelector<HTMLElement>(FOCUSABLE_SELECTOR);

  if (focusable) {
    focusable.focus({ preventScroll: true });
  }
}

/**
 * Прокручивает scrollable-контейнер к первому полю с ошибкой валидации.
 *
 * Ищет первый элемент с атрибутом `aria-invalid="true"` внутри указанного
 * контейнера (или `document.body`, если контейнер не указан) и прокручивает
 * его в видимую область.
 *
 * Если поле с ошибкой находится внутри scrollable-контейнера
 * (например, ScrollBar / Drawer / modal), скроллит родительский контейнер,
 * центрируя поле. Иначе использует `scrollIntoView`.
 *
 * После скролла пытается сфокусировать первый фокусируемый элемент
 * (input, textarea, select, button, [tabindex]) внутри поля с ошибкой.
 *
 * @param root - корневой элемент формы (опционально).
 *               Если не указан, поиск ведётся по всему document.
 * @returns `true`, если найден элемент с ошибкой и выполнен скролл;
 *          `false` — если элементов с ошибкой не найдено.
 *
 * @example
 * ```ts
 * // Поиск по всему документу
 * scrollToFirstValidationError();
 *
 * // Поиск внутри конкретного контейнера
 * scrollToFirstValidationError(formRef.current);
 * ```
 */
export function scrollToFirstValidationError(root?: HTMLElement): boolean {
  const container = root ?? document.body;

  const errorField = container.querySelector<HTMLElement>(ERROR_SELECTOR);

  if (!errorField) {
    return false;
  }

  const scrollParent = findScrollParent(errorField);

  if (scrollParent) {
    const parentRect = scrollParent.getBoundingClientRect();
    const elementRect = errorField.getBoundingClientRect();
    const relativeTop = elementRect.top - parentRect.top;
    const targetScroll =
      scrollParent.scrollTop +
      relativeTop -
      parentRect.height / 2 +
      elementRect.height / 2;

    scrollParent.scrollTo({
      top: Math.max(
        0,
        Math.min(targetScroll, scrollParent.scrollHeight - parentRect.height),
      ),
      behavior: 'smooth',
    });
  } else {
    errorField.scrollIntoView({
      block: 'center',
      behavior: 'smooth',
    });
  }

  focusFirstFocusable(errorField);

  return true;
}
