import { describe, it, expect, beforeEach, vi, Mock } from 'vitest';
import { RestService, ERESTMethod } from './restService';
import { axiosInstance } from './axios';
import { AxiosError } from 'axios';

// Мокаем axiosInstance
vi.mock('./axios', async () => {
  const actual = await vi.importActual('./axios');
  return {
    ...actual,
    axiosInstance: {
      request: vi.fn(),
    },
    processContentDisposition: actual.processContentDisposition,
  };
});

// Мокаем i18next и react-i18next
vi.mock('i18next', () => {
  const t = vi.fn().mockReturnValue('');
  const instance = {
    t,
    use: vi.fn().mockReturnThis(),
    init: vi.fn().mockResolvedValue(undefined),
    addResourceBundle: vi.fn(),
    options: { ns: [] },
    language: 'ru',
    isInitialized: true,
    changeLanguage: vi.fn(),
    getFixedT: vi.fn(),
    exists: vi.fn(),
  };
  return {
    default: instance,
    t: instance.t,
    createInstance: vi.fn().mockReturnValue({
      t: vi.fn().mockReturnValue(''),
      use: vi.fn().mockReturnThis(),
      init: vi.fn().mockResolvedValue(undefined),
      addResourceBundle: vi.fn(),
      options: { ns: [] },
      language: 'ru',
      isInitialized: true,
    }),
  };
});

vi.mock('react-i18next', () => ({
  initReactI18next: {
    type: '3rdParty',
    init: vi.fn(),
  },
}));

vi.mock('../../i18n', () => ({
  default: vi.fn(),
}));

// Мокаем глобальный window для dispatchEvent
const windowMock = {
  dispatchEvent: vi.fn(),
};
vi.stubGlobal('window', windowMock);
vi.stubGlobal('CustomEvent', vi.fn().mockImplementation((type, options) => ({
  type,
  detail: options?.detail || null,
})));

vi.mock('@sber-orm/ui-kit', async () => {
  const actual = await vi.importActual<typeof import('@sber-orm/ui-kit')>('@sber-orm/ui-kit');
  return {
    ...actual,
    notification: vi.fn(),
  };
});

describe('RestService', () => {
  let service: RestService;
  let mockRequest: Mock;

  beforeEach(() => {
    vi.clearAllMocks();
    mockRequest = vi.mocked(axiosInstance.request);
    service = new RestService('https://api.example.com');
  });

  describe('constructor', () => {
    it('should create an instance with URL', () => {
      const service = new RestService('https://api.example.com');
      expect(service.url).toBe('https://api.example.com');
    });

    it('should handle empty URL', () => {
      const service = new RestService('');
      expect(service.url).toBe('');
    });
  });

  describe('url getter', () => {
    it('should return the base URL', () => {
      expect(service.url).toBe('https://api.example.com');
    });
  });

  describe('HTTP methods', () => {
    it('should call baseRequest with GET method', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: true, body: { id: 1 } },
        status: 200,
        headers: {},
      });

      const result = await service.get({ resource: 'users' });
      expect(result).toEqual({
        success: true,
        body: { id: 1 },
        hasError: false,
      });
      expect(mockRequest).toHaveBeenCalledWith(
        expect.objectContaining({
          method: ERESTMethod.get,
          url: 'https://api.example.com/users',
        }),
      );
    });

    it('should call baseRequest with POST method', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: true, body: { id: 2 } },
        status: 201,
        headers: {},
      });

      const result = await service.post({
        resource: 'users',
        data: { name: 'John' },
      });
      expect(mockRequest).toHaveBeenCalledWith(
        expect.objectContaining({
          method: ERESTMethod.post,
          data: { name: 'John' },
          url: 'https://api.example.com/users',
        }),
      );
      expect(result).toEqual({
        success: true,
        body: { id: 2 },
        hasError: false,
      });
    });

    it('should call baseRequest with PUT method', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: true, body: { id: 1 } },
        status: 200,
        headers: {},
      });

      await service.put({ resource: 'users/1', data: { name: 'Jane' } });
      expect(mockRequest).toHaveBeenCalledWith(
        expect.objectContaining({
          method: ERESTMethod.put,
          data: { name: 'Jane' },
          url: 'https://api.example.com/users/1',
        }),
      );
    });

    it('should call baseRequest with PATCH method', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: true, body: { id: 1 } },
        status: 200,
        headers: {},
      });

      await service.patch({ resource: 'users/1', data: { name: 'Alice' } });
      expect(mockRequest).toHaveBeenCalledWith(
        expect.objectContaining({
          method: ERESTMethod.patch,
          data: { name: 'Alice' },
          url: 'https://api.example.com/users/1',
        }),
      );
    });

    it('should call baseRequest with DELETE method', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: true, body: { id: 1 } },
        status: 200,
        headers: {},
      });

      await service.delete({ resource: 'users/1' });
      expect(mockRequest).toHaveBeenCalledWith(
        expect.objectContaining({
          method: ERESTMethod.delete,
          url: 'https://api.example.com/users/1',
        }),
      );
    });

    it('should handle file download (getFile)', async () => {
      mockRequest.mockResolvedValueOnce({
        data: new Blob(['file content'], { type: 'text/plain' }),
        status: 200,
        headers: { 'content-type': 'text/plain' },
        request: {
          getResponseHeader: () => 'attachment; filename="test.txt"',
        },
      });

      const result = await service.getFile({ resource: 'download' });
      expect(result).toEqual({
        body: expect.any(Blob),
        fileName: 'test.txt',
        type: 'text/plain',
        success: true,
        hasError: false,
      });
    });

    it('should set hasError flag when response has error', async () => {
      mockRequest.mockResolvedValueOnce({
        data: { success: false, error: { code: 'ERROR_CODE', text: 'Error message' } },
        status: 200,
        headers: {},
      });

      const result = await service.get({ resource: 'users' });
      expect(result.hasError).toBe(true);
      expect(result.error).toEqual({ code: 'ERROR_CODE', text: 'Error message' });
    });

    it('should handle network errors in baseRequest', async () => {
      mockRequest.mockRejectedValueOnce(new Error('Network Error'));

      const result = await service.get({ resource: 'users' });
      expect(result).toEqual({
        error: { code: 'UNKNOWN_ERROR', text: 'An unexpected error occurred' },
        hasError: true,
        success: false,
      });
    });

    it('should handle Axios errors', async () => {
      const axiosError = new AxiosError(
        'error',
        'ERR_NETWORK',
        undefined,
        undefined,
        {
          status: 500,
          statusText: 'Server Error',
          data: { message: 'Internal Server Error' },
        } as any,
      );
      mockRequest.mockRejectedValueOnce(axiosError);

      const result = await service.get({ resource: 'users' });
      expect(result.error?.code).toBe('500');
    });

    it('should canceler should return success=true when error code is ERR_CANCELED', async () => {
      const axiosError = new AxiosError(
        'cancelled',
        'ERR_CANCELED',
        undefined,
        undefined,
        undefined,
      );
      mockRequest.mockRejectedValueOnce(axiosError);

      const result = await service.get({ resource: 'users' });
      expect(result).toEqual({ hasError: false, success: true });
    });

    describe('resource with base URL', () => {
      it('should join baseUrl and resource correctly', async () => {
        mockRequest.mockResolvedValueOnce({
          data: { success: true },
          status: 200,
          headers: {},
        });

        const service = new RestService('https://api.example.com/v1');
        await service.get({ resource: 'users' });
        const calledConfig = mockRequest.mock.calls[0][0];
        expect(calledConfig.url).toBe('https://api.example.com/v1/users');
      });

      it('should handle resource without leading slash', async () => {
        mockRequest.mockResolvedValueOnce({
          data: { success: true },
          status: 200,
          headers: {},
        });

        const service = new RestService('https://api.example.com/');
        await service.get({ resource: 'users' });
        const calledConfig = mockRequest.mock.calls[0][0];
        expect(calledConfig.url).toBe('https://api.example.com/users');
      });
    });
  });
});
