import { TNotificationType } from '@sber-orm/ui-kit';
import {
  AxiosError,
  AxiosRequestConfig,
  AxiosResponse,
  isAxiosError,
} from 'axios';
import { t } from 'i18next';
import type { ErrorMessage, Notification } from '../../@types/api';
import { EBusinessErrorTypes, ERESTErrorEvents } from '../../components';

import { axiosInstance, processContentDisposition } from './axios';

export enum ERESTMethod {
  post = 'post',
  get = 'get',
  put = 'put',
  patch = 'patch',
  delete = 'delete',
}

export type TRequestArguments<T = unknown> = AxiosRequestConfig<T> & {
  resource: string;
  isBlob?: boolean;
  /** Если true — HTTP-ошибка не уходит в глобальный ErrorBoundary.
   *  Вызывающий код сам решает, как её обработать. */
  bypassGlobalError?: boolean;
};

export interface IAPIResponse<T = unknown> {
  success: boolean;
  body?: T;
  error?: IErrorResponse;
  hasError?: boolean;
}

export interface IErrorResponse {
  code: string;
  text?: string;
  title?: string;
}

export interface IBlobResponse<T = unknown> extends IAPIResponse<T> {
  type?: string;
  fileName?: string;
}

export type TRESTServiceResponseType<T = unknown> = Promise<AxiosResponse<T>>;
export type TApiResponseType<T = unknown> = Promise<IAPIResponse<T>>;
export type TBlobResponseType<T = unknown> = Promise<IBlobResponse<T>>;

export class RestService {
  constructor(private readonly _url: string) {}

  get url() {
    return this._url;
  }

  private async baseRequest<T>(
    args: TRequestArguments,
  ): Promise<IAPIResponse<T> | IBlobResponse<T>> {
    const {
      data = null,
      headers = {},
      method,
      params = {},
      resource = '',
      isBlob = false,
      ...config
    } = args;
    const url = resource
      ? `${this._url.replace(/\/+$/, '')}/${resource.replace(/^\/+/, '')}`
      : this._url;

    try {
      const request = await axiosInstance.request<IAPIResponse<T>>({
        data,
        headers: { ...headers },
        method,
        params: { ...params },
        url,
        responseType: isBlob ? 'blob' : 'json',
        ...config,
      } as AxiosRequestConfig<T>);

      if (isBlob) {
        return this.processBlobResponse(request) as IBlobResponse<T>;
      }

      const responseData = request.data as IAPIResponse<T>;
      return {
        ...responseData,
        hasError: this.processBusinessError(responseData),
      };
    } catch (error: unknown) {
      return this.handleError(error, args) as
        | IAPIResponse<T>
        | IBlobResponse<T>;
    }
  }

  private processBlobResponse<T>(response: AxiosResponse<T>): IBlobResponse<T> {
    const fileName = processContentDisposition(
      response.request.getResponseHeader('Content-Disposition'),
    );

    return {
      body: response.data,
      fileName,
      hasError: this.processBusinessError(response.data),
      success: true,
      type: response.headers['content-type'],
    } as IBlobResponse<T>;
  }

  private handleError(
    error: unknown,
    options: { isBlob?: boolean; bypassGlobalError?: boolean } = {},
  ): IAPIResponse {
    if (isAxiosError(error)) {
      if (error.code === AxiosError.ERR_CANCELED) {
        return {
          hasError: false,
          success: true,
        };
      }

      if (!options.isBlob && !options.bypassGlobalError) {
        this.processHttpError(error as AxiosError);
      }

      const statusCode = error.response?.status;
      const responseData = error.response?.data as
        | { message?: string }
        | string
        | undefined;

      let errorText: string;

      if (statusCode === 423) {
        // HTTP 423 (Locked) — антивирусная проверка не пройдена.
        // Берём перевод или сообщение из тела ответа.
        const serverMessage =
          typeof responseData === 'object'
            ? responseData?.message
            : typeof responseData === 'string'
              ? responseData
              : undefined;

        errorText =
          t('file will not be processed', { ns: 'error' }) ||
          serverMessage ||
          error.response?.statusText ||
          error.message;
      } else {
        errorText = error.response?.statusText || error.message;
      }

      return {
        error: {
          code: statusCode?.toString() || 'UNKNOWN_ERROR',
          text: errorText,
        },
        hasError: true,
        success: false,
      };
    }

    // Обработка неожиданных ошибок
    return {
      error: {
        code: 'UNKNOWN_ERROR',
        text: 'An unexpected error occurred',
      },
      hasError: true,
      success: false,
    };
  }

  private async requestHtml<T>(arguments_: TRequestArguments): Promise<string> {
    const {
      data = null,
      headers = {},
      method,
      params: parameters = {},
      resource = '',
      ...config
    } = arguments_;

    const url = `${this._url}/${resource}`;

    try {
      const request = await axiosInstance.request<
        IAPIResponse<T>,
        AxiosResponse<IAPIResponse<T>>
      >({
        data,
        headers: {
          ...headers,
          Accept:
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        method,
        params: parameters,
        url,
        ...config,
      } as AxiosRequestConfig<T>);

      if (typeof request.data === 'string') {
        return request.data;
      }

      return Object.values(request.data.body || {}).join('');
      // biome-ignore lint/suspicious/noExplicitAny: reason
    } catch (error: any) {
      this.processHttpError(error as AxiosError);

      return '';
    }
  }

  async getFile<T>(args: TRequestArguments): TBlobResponseType<T> {
    return (await this.baseRequest<T>({
      method: ERESTMethod.get,
      responseType: 'blob',
      isBlob: true,
      ...args,
    })) as IBlobResponse<T>;
  }

  async get<T>(args: Omit<TRequestArguments, 'data'>): TApiResponseType<T> {
    return await this.baseRequest<T>({ method: ERESTMethod.get, ...args });
  }

  async post<T>(args: TRequestArguments): TApiResponseType<T> {
    return await this.baseRequest<T>({ method: ERESTMethod.post, ...args });
  }

  async put<T>(args: TRequestArguments): TApiResponseType<T> {
    return await this.baseRequest<T>({ method: ERESTMethod.put, ...args });
  }

  async patch<T>(args: TRequestArguments): TApiResponseType<T> {
    return await this.baseRequest<T>({ method: ERESTMethod.patch, ...args });
  }

  async delete<T>(args: TRequestArguments): TApiResponseType<T> {
    return await this.baseRequest<T>({ method: ERESTMethod.delete, ...args });
  }

  async getHtml<T>(arguments_: Omit<TRequestArguments, 'data'>) {
    return await this.requestHtml<T>({
      method: ERESTMethod.get,
      ...arguments_,
    });
  }

  private triggerErrorEvent(
    eventType: ERESTErrorEvents,
    data: AxiosError | ErrorMessage,
  ) {
    const errorEvent = new CustomEvent(eventType, { detail: data });
    window.dispatchEvent(errorEvent);
  }

  private processHttpError(error: AxiosError) {
    this.triggerErrorEvent(ERESTErrorEvents.http, error);
  }

  private processBusinessError(responseData: unknown): boolean {
    let hasError = false;

    const body =
      typeof responseData === 'object' && responseData !== null
        ? // biome-ignore lint/suspicious/noExplicitAny: reason
          (responseData as any).body
        : undefined;
    const errorObj =
      typeof responseData === 'object' && responseData !== null
        ? // biome-ignore lint/suspicious/noExplicitAny: reason
          (responseData as any).error
        : undefined;
    const success =
      typeof responseData === 'object' && responseData !== null
        ? // biome-ignore lint/suspicious/noExplicitAny: reason
          (responseData as any).success
        : undefined;

    const notifications: Notification[] = body?.notifications ?? [];

    if (success === false && (errorObj as IErrorResponse)?.text) {
      hasError = true;
      this.triggerErrorEvent(
        ERESTErrorEvents.business,
        errorObj as ErrorMessage,
      );
    }

    notifications.forEach((n: Notification) => {
      this.triggerErrorEvent(ERESTErrorEvents.business, {
        text: n?.text || '',
        title: n?.title || t('translation:error'),
        type: (n?.notificationType ?? 'error') as TNotificationType,
        code: EBusinessErrorTypes.notification,
      } as ErrorMessage);
    });

    return hasError;
  }
}
