import axios, {
  type AxiosInstance,
  AxiosProgressEvent,
  type AxiosResponse,
  CreateAxiosDefaults,
  InternalAxiosRequestConfig,
} from 'axios';
import qs from 'query-string';
import { waitForSessionRequestTurn } from './sessionRequestQueue';

type SessionQueuedRequestConfig = InternalAxiosRequestConfig & {
  releaseSessionRequestTurn?: () => void;
};

const configCreateAxiosDefaults = {
  // `headers` - это пользовательские заголовки для запроса
  headers: { Accept: 'application/json' },
  // `maxRedirects` определяет максимальное количество перенаправлений в node.js.
  maxRedirects: 0,
  // `paramsSerializer` это дополнительная функция, отвечающая за сериализацию `params`
  paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'comma' }),
} as CreateAxiosDefaults;

const interceptorsResponseCallback = (response: AxiosResponse) => {
  if (
    'request' in response &&
    'requestURL' in response.request &&
    'responseURL' in response.request &&
    response.request.requestURL !== response.request.responseURL
  ) {
    return Promise.reject(response);
  }

  return Promise.resolve(response);
};

function releaseSessionRequestTurn(config?: InternalAxiosRequestConfig) {
  const release = (config as SessionQueuedRequestConfig | undefined)
    ?.releaseSessionRequestTurn;

  release?.();
}

function applySessionRequestQueue(instance: AxiosInstance) {
  instance.interceptors.request.use(async (config) => {
    const release = await waitForSessionRequestTurn();

    (config as SessionQueuedRequestConfig).releaseSessionRequestTurn = release;

    return config;
  });

  instance.interceptors.response.use(
    (response) => {
      releaseSessionRequestTurn(response.config);

      return interceptorsResponseCallback(response);
    },
    (error) => {
      releaseSessionRequestTurn(error?.config);

      return error && Promise.reject(error);
    },
  );
}

export const axiosInstance = axios.create(configCreateAxiosDefaults);
applySessionRequestQueue(axiosInstance);

export function createClient(url: string) {
  const instance = axios.create({
    ...configCreateAxiosDefaults,
    baseURL: url,
  });

  applySessionRequestQueue(instance);

  return instance;
}

export const onProgressEvent = (onProgress?: (_: number) => void) => {
  return function (progressEvent: AxiosProgressEvent) {
    onProgress?.(
      Math.round((progressEvent.loaded * 100) / (progressEvent.total || 1)),
    );
  };
};

export const setAxiosRequestInterceptor = (
  requestConfig: InternalAxiosRequestConfig,
) => {
  axiosInstance.interceptors.request.use(
    (config) =>
      ({
        ...config,
        ...requestConfig,
        headers: {
          ...config.headers,
          ...requestConfig.headers,
        },
      }) as InternalAxiosRequestConfig,
    (error) => Promise.reject(error),
  );
};

export const processContentDisposition = (disposition: string | null) => {
  if (!disposition || typeof disposition !== 'string') {
    throw new TypeError('argument string is required');
  }

  const DISPOSITION_TYPE_REGEXP =
    // biome-ignore lint/suspicious/noControlCharactersInRegex: Unexpected control character in a regular expression
    /^([!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*(?:$|;)/;
  const PARAM_REGEXP =
    // biome-ignore lint/suspicious/noControlCharactersInRegex: Unexpected control character in a regular expression
    /;[\x09\x20]*([!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*=[\x09\x20]*("(?:[\x20!\x23-\x5b\x5d-\x7e\x80-\xff]|\\[\x20-\x7e])*"|[!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*/g;
  // biome-ignore lint/suspicious/noControlCharactersInRegex: Unexpected control character in a regular expression
  const QESC_REGEXP = /\\([\u0000-\u007f])/g;
  const EXT_VALUE_REGEXP =
    /^([A-Za-z0-9!#$%&+\-^_`{}~]+)'(?:[A-Za-z]{2,3}(?:-[A-Za-z]{3}){0,3}|[A-Za-z]{4,8}|)'((?:%[0-9A-Fa-f]{2}|[A-Za-z0-9!#$&+.^_`|~-])+)$/;
  const HEX_ESCAPE_REPLACE_REGEXP = /%([0-9A-Fa-f]{2})/g;
  const NON_LATIN1_REGEXP = /[^\x20-\x7e\xa0-\xff]/g;

  function pdecode(_: string, hex: string) {
    return String.fromCharCode(Number.parseInt(hex, 16));
  }

  function getlatin1(val: string) {
    // simple Unicode -> ISO-8859-1 transformation
    return String(val).replace(NON_LATIN1_REGEXP, '?');
  }

  function decodefield(str: string) {
    const match = EXT_VALUE_REGEXP.exec(str);

    if (!match) {
      throw new TypeError('invalid extended field value');
    }

    const charset = match[1].toLowerCase();
    const encoded = match[2];
    let value;

    switch (charset) {
      case 'iso-8859-1': {
        // to binary string
        const binary = encoded.replace(HEX_ESCAPE_REPLACE_REGEXP, pdecode);
        value = getlatin1(binary);
        break;
      }
      case 'utf-8':
      case 'utf8':
        value = decodeURIComponent(encoded);
        break;
      default:
        throw new TypeError('unsupported charset in extended field');
    }

    return value;
  }

  let matches = DISPOSITION_TYPE_REGEXP.exec(disposition);

  if (!matches) {
    throw new TypeError('invalid type format');
  }

  let index = matches[0].length;
  const type = matches[1].toLowerCase();

  const names = [];
  const params: Record<string, string | number> = {};
  let key;
  let value;

  // calculate index to start at
  index = PARAM_REGEXP.lastIndex =
    matches[0].slice(-1) === ';' ? index - 1 : index;

  if (type !== 'attachment') {
    throw new TypeError('invalid type format');
  }

  while ((matches = PARAM_REGEXP.exec(disposition))) {
    if (matches.index !== index) {
      throw new TypeError('invalid parameter format');
    }

    index += matches[0].length;
    key = matches[1].toLowerCase();
    value = matches[2];

    if (names.indexOf(key) !== -1) {
      throw new TypeError('invalid duplicate parameter');
    }

    names.push(key);

    if (key.indexOf('*') + 1 === key.length) {
      // decode extended value
      key = key.slice(0, -1);
      value = decodefield(value);
      //
      // // overwrite existing value
      params[key] = value;
      continue;
    }

    if (typeof params[key] === 'string') {
      continue;
    }

    if (value[0] === '"') {
      // remove quotes and escapes
      value = value.slice(1, -1).replace(QESC_REGEXP, '$1');
    }

    params[key] = value;
  }

  if (index !== -1 && index !== disposition.length) {
    throw new TypeError('invalid parameter format');
  }
  if (typeof params['filename'] !== 'string') {
    throw new TypeError('invalid parameter format');
  }

  return params['filename'];
};
