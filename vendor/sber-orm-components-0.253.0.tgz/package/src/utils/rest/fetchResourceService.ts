import { RestService } from './restService';

export class FetchResourceService {
  public rest: RestService;

  constructor(private readonly url: string) {
    this.rest = new RestService(this.url);
  }
}
