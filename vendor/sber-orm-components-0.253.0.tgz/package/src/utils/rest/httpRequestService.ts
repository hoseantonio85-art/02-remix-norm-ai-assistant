export type TServicePromise<T> = Promise<T> & {
  abort: () => void;
};

export type TXhrBody = Document | XMLHttpRequestBodyInit | null;

export type TXhrProps = Pick<RequestInit, 'method' | 'headers'>;

export const HttpRequestService = <T>(
  url: string,
  body: TXhrBody = null,
  options: TXhrProps = {},
): TServicePromise<T> => {
  const controller = new AbortController();
  const { signal } = controller;

  const fetchOptions = {
    method: options.method || 'POST',
    headers: options.headers,
    body,
    signal,
    mode: 'cors',
    credentials: 'same-origin',
  } as RequestInit;

  const promise = fetch(url, fetchOptions)
    .then(async (response) => {
      if (!response.ok) {
        // Обработка ошибок HTTP (например, 404, 500)
        const errorResponse = await response.json().catch(() => ({
          status: response.status,
          statusText: response.statusText,
        }));
        throw (
          errorResponse ?? {
            status: response.status,
            statusText: response.statusText,
          }
        );
      }

      // Сначала пытаемся обработать JSON
      try {
        const jsonResponse = await response.json();
        return jsonResponse as T;
      } catch (jsonError) {
        // Если JSON не удалось распарсить, пробуем обработать текст
        try {
          const textResponse = await response.text();
          return textResponse as unknown as T;
        } catch (textError) {
          // Если и text() выбрасывает ошибку, возвращаем "Invalid JSON"
          throw new Error('Invalid JSON');
        }
      }
    })
    .catch((error) => {
      // Обработка ошибок сети или других исключений
      throw error;
    }) as TServicePromise<T>;

  promise.abort = () => controller.abort();

  return promise;
};
