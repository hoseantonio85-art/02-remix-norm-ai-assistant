import { describe, it, expect, beforeEach } from 'vitest';
import {
  waitForSessionRequestTurn,
  resetSessionRequestQueue,
} from './sessionRequestQueue';

describe('sessionRequestQueue', () => {
  beforeEach(() => {
    resetSessionRequestQueue();
  });

  describe('waitForSessionRequestTurn', () => {
    it('should return a release function', async () => {
      const release = await waitForSessionRequestTurn();

      expect(release).toBeInstanceOf(Function);
      release();
    });

    it('should allow the first caller to proceed immediately without waiting', async () => {
      const order: string[] = [];

      const release1 = await waitForSessionRequestTurn();
      order.push('first-acquired');

      release1();
      order.push('first-released');

      expect(order).toEqual(['first-acquired', 'first-released']);
    });

    it('should queue the second caller until the first releases its turn', async () => {
      const order: string[] = [];

      const release1 = await waitForSessionRequestTurn();
      order.push('first-acquired');

      // Second caller starts but should not resolve until release1 is called
      const secondCaller = waitForSessionRequestTurn().then((release2) => {
        order.push('second-acquired');
        release2();
        order.push('second-released');
      });

      // Give the second caller a chance to try — still waiting
      await Promise.resolve();
      expect(order).toEqual(['first-acquired']);

      release1();
      order.push('first-released');

      await secondCaller;
      expect(order).toEqual([
        'first-acquired',
        'first-released',
        'second-acquired',
        'second-released',
      ]);
    });

    it('should maintain sequential order for multiple callers', async () => {
      const order: number[] = [];
      const totalCallers = 5;

      async function caller(id: number) {
        const release = await waitForSessionRequestTurn();
        order.push(id);
        release();
      }

      const promises = [];
      for (let i = 0; i < totalCallers; i++) {
        promises.push(caller(i));
        // Small delay to ensure each caller starts in order
        await Promise.resolve();
      }

      await Promise.all(promises);
      expect(order).toEqual([0, 1, 2, 3, 4]);
    });

    it('should not resolve the second caller when the release function is called more than once', async () => {
      const order: string[] = [];

      const release1 = await waitForSessionRequestTurn();
      order.push('first-acquired');

      const secondCaller = waitForSessionRequestTurn().then(() => {
        order.push('second-acquired');
      });

      // Call release twice — second call should be a no-op
      release1();
      release1();
      order.push('first-released');

      await secondCaller;
      expect(order).toEqual([
        'first-acquired',
        'first-released',
        'second-acquired',
      ]);
    });

    it('should work correctly when release is called without awaiting', async () => {
      const order: string[] = [];

      const release1 = await waitForSessionRequestTurn();
      order.push('first-acquired');
      release1();
      order.push('first-released');

      const release2 = await waitForSessionRequestTurn();
      order.push('second-acquired');
      release2();
      order.push('second-released');

      expect(order).toEqual([
        'first-acquired',
        'first-released',
        'second-acquired',
        'second-released',
      ]);
    });

    it('should handle concurrent callers and preserve strict order', async () => {
      const executionOrder: number[] = [];

      async function worker(id: number) {
        const release = await waitForSessionRequestTurn();
        // Simulate some async work
        await Promise.resolve();
        executionOrder.push(id);
        release();
      }

      // Launch all workers concurrently
      const promises = Array.from({ length: 10 }, (_, i) => worker(i));

      await Promise.all(promises);

      // Workers should have acquired turns in order 0-9
      expect(executionOrder).toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    });

    it('should not break if the previous requester does not release (error recovery)', async () => {
      const order: string[] = [];

      const release1 = await waitForSessionRequestTurn();
      order.push('first-acquired');
      release1();
      order.push('first-released');

      const release2 = await waitForSessionRequestTurn();
      order.push('second-acquired');
      release2();
      order.push('second-released');

      expect(order).toEqual([
        'first-acquired',
        'first-released',
        'second-acquired',
        'second-released',
      ]);
    });
  });
});