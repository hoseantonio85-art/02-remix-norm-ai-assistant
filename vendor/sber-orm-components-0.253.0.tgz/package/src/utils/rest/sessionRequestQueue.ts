let lastRequest = Promise.resolve();

/**
 * @internal Reset the queue state. Used in tests only.
 */
export function resetSessionRequestQueue() {
  lastRequest = Promise.resolve();
}

export async function waitForSessionRequestTurn() {
  let releaseCurrentRequest!: () => void;

  const currentRequest = new Promise<void>((resolve) => {
    releaseCurrentRequest = resolve;
  });
  const previousRequest = lastRequest.catch(() => undefined);

  lastRequest = previousRequest.then(() => currentRequest);

  await previousRequest;

  let isReleased = false;

  return () => {
    if (!isReleased) {
      isReleased = true;
      releaseCurrentRequest();
    }
  };
}
