import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { HttpRequestService } from './httpRequestService';

// Мокируем fetch
global.fetch = vi.fn();

describe('HttpRequestService', () => {
    beforeEach(() => {
        vi.clearAllMocks(); // Очищаем моки перед каждым тестом
    });

    afterEach(() => {
        vi.restoreAllMocks(); // Восстанавливаем моки после каждого теста
    });

    // 1. Проверка успешного GET-запроса
    it('should make a successful GET request', async () => {
        const mockResponse = { data: 'test data' };
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.resolve(mockResponse),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).resolves.toEqual(mockResponse);
    });

    // 2. Проверка успешного POST-запроса
    it('should make a successful POST request', async () => {
        const mockResponse = { data: 'test data' };
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.resolve(mockResponse),
        } as Response);

        const request = HttpRequestService<{ data: string }>(
            'https://api.example.com/data',
            JSON.stringify({ key: 'value' }),
            { method: 'POST', headers: { 'Content-Type': 'application/json' } },
        );
        await expect(request).resolves.toEqual(mockResponse);
    });

    // 3. Проверка обработки ошибки HTTP (404)
    it('should handle HTTP error (404)', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve({ error: 'Not Found' }),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ error: 'Not Found' });
    });

    // 4. Проверка обработки ошибки HTTP (500)
    it('should handle HTTP error (500)', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 500,
            statusText: 'Internal Server Error',
            json: () => Promise.resolve({ error: 'Server Error' }),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ error: 'Server Error' });
    });

    // 5. Проверка обработки ошибки сети
    it('should handle network error', async () => {
        vi.mocked(fetch).mockRejectedValueOnce(new Error('Network Error'));

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toThrow('Network Error');
    });

    // 6. Проверка отмены запроса
    it('should abort the request', async () => {
        // Мокируем fetch, чтобы он выбрасывал AbortError при отмене
        vi.mocked(fetch).mockImplementation((_, requestInit) => {
            return new Promise((_, reject) => {
                const signal = requestInit?.signal;
                signal?.addEventListener('abort', () => {
                    reject(new DOMException('The user aborted a request.', 'AbortError'));
                });
            });
        });

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        request.abort();

        await expect(request).rejects.toThrow('The user aborted a request.');
    });

    // 7. Проверка обработки пустого ответа
    it('should handle empty response', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.resolve(null),
        } as Response);

        const request = HttpRequestService<null>('https://api.example.com/data');
        await expect(request).resolves.toBeNull();
    });

    // 8. Проверка обработки невалидного JSON
    it('should handle invalid JSON response', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.reject(new Error('Invalid JSON')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toThrow('Invalid JSON');
    });

    // 9. Проверка обработки пустого тела запроса
    it('should handle empty request body', async () => {
        const mockResponse = { data: 'test data' };
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.resolve(mockResponse),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data', null);
        await expect(request).resolves.toEqual(mockResponse);
    });

    // 10. Проверка обработки текстового ответа
    it('should handle text response', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: true,
            json: () => Promise.reject(new Error('Invalid JSON')), // json выбрасывает ошибку
            text: () => Promise.resolve('test data'), // text возвращает текстовый ответ
        } as Response);

        const request = HttpRequestService<string>('https://api.example.com/data');
        await expect(request).resolves.toBe('test data');
    });

    // 11. Проверка обработки ответа с ошибкой (без JSON)
    it('should handle error response without JSON', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 12. Проверка обработки ответа с ошибкой (с JSON)
    it('should handle error response with JSON', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve({ error: 'Not Found' }),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ error: 'Not Found' });
    });

    // 13. Проверка обработки ответа с ошибкой (с текстом)
    it('should handle error response with text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve('Not Found'),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 14. Проверка обработки ответа с ошибкой (с пустым телом)
    it('should handle error response with empty body', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 15. Проверка обработки ответа с ошибкой (с невалидным JSON)
    it('should handle error response with invalid JSON', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve('Invalid JSON'),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 16. Проверка обработки ответа с ошибкой (с пустым JSON)
    it('should handle error response with empty JSON', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 17. Проверка обработки ответа с ошибкой (с пустым текстом)
    it('should handle error response with empty text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 18. Проверка обработки ответа с ошибкой (с невалидным текстом)
    it('should handle error response with invalid text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 19. Проверка обработки ответа с ошибкой (с пустым JSON и текстом)
    it('should handle error response with empty JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 20. Проверка обработки ответа с ошибкой (с невалидным JSON и текстом)
    it('should handle error response with invalid JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 21. Проверка обработки ответа с ошибкой (с пустым JSON и невалидным текстом)
    it('should handle error response with empty JSON and invalid text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 22. Проверка обработки ответа с ошибкой (с невалидным JSON и пустым текстом)
    it('should handle error response with invalid JSON and empty text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 23. Проверка обработки ответа с ошибкой (с пустым JSON и текстом)
    it('should handle error response with empty JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 24. Проверка обработки ответа с ошибкой (с невалидным JSON и текстом)
    it('should handle error response with invalid JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 25. Проверка обработки ответа с ошибкой (с пустым JSON и невалидным текстом)
    it('should handle error response with empty JSON and invalid text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 26. Проверка обработки ответа с ошибкой (с невалидным JSON и пустым текстом)
    it('should handle error response with invalid JSON and empty text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 27. Проверка обработки ответа с ошибкой (с пустым JSON и текстом)
    it('should handle error response with empty JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.resolve(null),
            text: () => Promise.resolve(''),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });

    // 28. Проверка обработки ответа с ошибкой (с невалидным JSON и текстом)
    it('should handle error response with invalid JSON and text', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            ok: false,
            status: 404,
            statusText: 'Not Found',
            json: () => Promise.reject(new Error('Invalid JSON')),
            text: () => Promise.reject(new Error('Invalid text')),
        } as Response);

        const request = HttpRequestService<{ data: string }>('https://api.example.com/data');
        await expect(request).rejects.toEqual({ status: 404, statusText: 'Not Found' });
    });
});
