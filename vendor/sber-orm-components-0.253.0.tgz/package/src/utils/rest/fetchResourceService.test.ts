import { describe, it, expect } from 'vitest';
import { FetchResourceService } from './fetchResourceService';
import { RestService } from './restService';

describe('FetchResourceService', () => {
  it('should create an instance with a URL', () => {
    const service = new FetchResourceService('https://api.example.com');
    expect(service).toBeInstanceOf(FetchResourceService);
    expect(service.rest).toBeInstanceOf(RestService);
    expect(service.rest.url).toBe('https://api.example.com');
  });

  it('should handle empty URL string', () => {
    const service = new FetchResourceService('');
    expect(service.rest.url).toBe('');
  });

  it('should have rest property that is public', () => {
    const service = new FetchResourceService('https://api.example.com');
    expect(service.rest).toBeDefined();
    expect(service.rest.url).toBe('https://api.example.com');
  });
});
