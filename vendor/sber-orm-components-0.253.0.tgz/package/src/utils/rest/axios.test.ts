import { describe, it, expect, vi } from 'vitest';
import {
  axiosInstance,
  onProgressEvent,
  setAxiosRequestInterceptor,
  processContentDisposition,
} from './axios';
import { AxiosProgressEvent } from 'axios';

describe('axios', () => {
  describe('axiosInstance', () => {
    it('should create axios instance with default config', () => {
      expect(axiosInstance).toBeDefined();
      expect(axiosInstance.defaults.headers.common.Accept).toBe('application/json, text/plain, */*');
      expect(axiosInstance.defaults.maxRedirects).toBe(0);
    });

    it('should have paramsSerializer configured for comma arrays', () => {
      const params = { ids: [1, 2, 3], status: 'active' };
      // Проверяем, что paramsSerializer существует и является функцией
      if (axiosInstance.defaults.paramsSerializer) {
        // biome-ignore lint: using any for test compatibility
        const serialized = (axiosInstance.defaults.paramsSerializer as any)(params);
        // query-string with arrayFormat: comma outputs comma-separated values without URL-encoding commas
        expect(serialized).toBe('ids=1,2,3&status=active');
      } else {
        expect.fail('paramsSerializer should be defined');
      }
    });
  });

  describe('onProgressEvent', () => {
    it('should return a function that calculates progress percentage', () => {
      const callback = vi.fn();
      const handler = onProgressEvent(callback);

      const progressEvent: AxiosProgressEvent = {
        loaded: 50,
        total: 100,
        lengthComputable: true,
        bytes: 50,
      };

      handler(progressEvent);
      expect(callback).toHaveBeenCalledWith(50);
    });

    it('should handle total = 0 gracefully', () => {
      const callback = vi.fn();
      const handler = onProgressEvent(callback);

      const progressEvent: AxiosProgressEvent = {
        loaded: 0,
        total: 0,
        lengthComputable: false,
        bytes: 0,
      };

      handler(progressEvent);
      expect(callback).toHaveBeenCalledWith(0);
    });

    it('should round the percentage', () => {
      const callback = vi.fn();
      const handler = onProgressEvent(callback);

      const progressEvent: AxiosProgressEvent = {
        loaded: 33,
        total: 100,
        lengthComputable: true,
        bytes: 33,
      };

      handler(progressEvent);
      expect(callback).toHaveBeenCalledWith(33);
    });
  });

  describe('setAxiosRequestInterceptor', () => {
    it('should add request interceptor', () => {
      const useSpy = vi.spyOn(
        axiosInstance.interceptors.request,
        'use',
      );
      setAxiosRequestInterceptor({ headers: { Authorization: 'Bearer token' } as any });
      expect(useSpy).toHaveBeenCalled();
    });
  });

  describe('processContentDisposition', () => {
    it('should extract filename from Content-Disposition header', () => {
      const disposition = 'attachment; filename="test file.csv"';
      const filename = processContentDisposition(disposition);
      expect(filename).toBe('test file.csv');
    });

    it('should handle filename without quotes', () => {
      const disposition = 'attachment; filename=test.txt';
      const filename = processContentDisposition(disposition);
      expect(filename).toBe('test.txt');
    });

    it('should handle UTF-8 filename with extension', () => {
      const disposition = "attachment; filename*=utf-8''%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80.csv";
      const filename = processContentDisposition(disposition);
      // Декодированный UTF-8 filename должен быть 'пример.csv'
      expect(filename).toBe('пример.csv');
    });

    it('should throw error for invalid disposition type', () => {
      expect(() => processContentDisposition('inline; filename=test.txt'))
        .toThrow('invalid type format');
    });

    it('should throw error for null or undefined', () => {
      expect(() => processContentDisposition(null as any))
        .toThrow('argument string is required');
      expect(() => processContentDisposition(undefined as any))
        .toThrow('argument string is required');
    });

    it('should throw error for empty string', () => {
      expect(() => processContentDisposition(''))
        .toThrow('argument string is required');
    });

    it('should throw error for non-string', () => {
      expect(() => processContentDisposition(123 as any))
        .toThrow('argument string is required');
    });
  });
});
