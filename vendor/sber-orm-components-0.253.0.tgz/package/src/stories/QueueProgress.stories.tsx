import { Meta, StoryFn } from '@storybook/react';

import { QueueProgress as QueueProgressComponent } from '..';
import { Container, Item } from './utils';

const meta: Meta<typeof QueueProgressComponent> = {
  component: QueueProgressComponent,
  title: 'components/QueueProgress',
};

export default meta;

export const QueueProgress: StoryFn<typeof QueueProgressComponent> = () => {
  return (
    <Container>
      <Item label='Empty'>
        <QueueProgressComponent />
      </Item>
      <Item label='Not empty'>
        <QueueProgressComponent
          elements={['Task 1', 'Task 2', 'Task 3']}
          progress={0.5}
        />
      </Item>
    </Container>
  );
};
